// Interfaz base para estrategias de optimización de rutas
public interface RouteOptimizationStrategy {
    void optimizeRoute(Route route);
}

// Implementación base de optimización de rutas
public class StandardRouteService implements RouteOptimizationStrategy {
    @Override
    public void optimizeRoute(Route route) {
        // Lógica de optimización de ruta estándar
    }
}