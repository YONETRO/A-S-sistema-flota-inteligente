// Servicio dedicado únicamente a la gestión de vehículos
public class FleetVehicleService {
    private FleetVehicleRepository vehicleRepository;

    // Constructor para inyección de dependencia del repositorio
    public FleetVehicleService(FleetVehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }

    // Método para recuperar un vehículo por su identificador
    public TransportUnit getVehicleById(long id) {
        return vehicleRepository.findById(id);
    }

    // Método para agregar un nuevo vehículo
    public void addVehicle(TransportUnit vehicle) {
        vehicleRepository.save(vehicle);
    }
}