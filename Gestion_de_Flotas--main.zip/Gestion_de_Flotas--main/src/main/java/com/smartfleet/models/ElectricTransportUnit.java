// Clase base que representa un vehículo genérico
public class TransportUnit {
    private String modelName;
    private String licensePlate;
}

// Subclase que extiende las capacidades del vehículo base
public class ElectricTransportUnit extends TransportUnit {
    private int energyCharge;

    // Método para obtener el nivel de carga del vehículo eléctrico
    @Override
    public int getEnergyLevel() {
        return energyCharge;
    }

    // Constructor para inicializar un vehículo eléctrico
    public ElectricTransportUnit(int energyCharge) {
        this.energyCharge = energyCharge;
    }
    
    public class FleetManager {
        public static void main(String[] args) {
            TransportUnit myCar = new ElectricTransportUnit(80); 
            System.out.println("Energy level: " + myCar.getEnergyLevel());
        }
    }
}