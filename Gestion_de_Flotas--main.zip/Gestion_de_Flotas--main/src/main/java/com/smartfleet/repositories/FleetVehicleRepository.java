// Interfaz específica para operaciones de gestión de vehículos
public interface FleetVehicleRepository {
    TransportUnit findById(long id);
    void save(TransportUnit vehicle);
}

// Interfaz específica para operaciones de gestión de rutas
public interface RouteManagementRepository {
    Route findById(long id);
    void save(Route route);
}