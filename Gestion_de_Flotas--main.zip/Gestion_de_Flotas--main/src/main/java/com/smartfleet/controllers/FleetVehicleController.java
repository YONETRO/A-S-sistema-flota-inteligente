//dependencias dip
//las clases de alto nivel nunca dependeran de una de alto nivel

// Controlador de vehículos que gestiona la adición de unidades
public class FleetVehicleController {
    private final VehicleManagementService vehicleManagementService;

    public FleetVehicleController(VehicleManagementService vehicleManagementService) {
        this.vehicleManagementService = vehicleManagementService;
    }

    // Método para registrar un nuevo vehículo en el sistema
    public void addVehicle(Fleet vehicle) {
        vehicleManagementService.addVehicle(vehicle);
    }
}

//"Fleetvehiclecontroller" clase alta